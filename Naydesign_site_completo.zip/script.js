// ===============================
// NAYDESIGN — CONFIGURAÇÃO RÁPIDA
// Edite apenas estas informações.
// ===============================
const CONFIG = {
  whatsapp: "5511999999999", // coloque seu WhatsApp com DDI + DDD, sem espaços
  mensagem: "Olá! Gostaria de agendar um horário na Naydesign. Poderia me informar a disponibilidade e os valores?"
};

const whatsappUrl = `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(CONFIG.mensagem)}`;
["topWhatsapp","heroWhatsapp","contactWhatsapp"].forEach(id => {
  const el = document.getElementById(id);
  if (el) el.href = whatsappUrl;
});

document.getElementById("phoneDisplay").textContent =
  CONFIG.whatsapp === "5511999999999" ? "(coloque seu número)" : CONFIG.whatsapp;

document.getElementById("year").textContent = new Date().getFullYear();

const menu = document.querySelector(".menu");
const nav = document.querySelector(".nav");
menu.addEventListener("click", () => nav.classList.toggle("open"));
document.querySelectorAll(".nav a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));
