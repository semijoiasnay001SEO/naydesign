# NAYDESIGN — Site gratuito

## Como editar
Abra `script.js` e altere:
- `whatsapp`: seu número com 55 + DDD + número, sem espaços.
- `mensagem`: texto que aparecerá no WhatsApp.

No `index.html`, você também pode alterar:
- endereço
- Instagram
- horários
- serviços
- depoimentos
- valores

## Como publicar grátis
### GitHub Pages
1. Crie uma conta no GitHub.
2. Crie um repositório público chamado `naydesign`.
3. Envie todos os arquivos desta pasta.
4. Vá em Settings > Pages.
5. Em Source, escolha "Deploy from a branch".
6. Selecione a branch `main` e a pasta `/root`.
7. Salve.
8. Seu site ficará disponível em um endereço `seuusuario.github.io/naydesign`.

### Netlify
Também é possível publicar arrastando a pasta para o painel de deploy do Netlify.

## Importante
As imagens da galeria são artes temporárias feitas em CSS. Substitua por fotos reais dos seus trabalhos para deixar o site mais profissional.
